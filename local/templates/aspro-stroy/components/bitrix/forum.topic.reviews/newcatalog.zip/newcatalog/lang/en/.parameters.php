<?
$MESS["F_SHOW_LINK_TO_FORUM"] = "Show link to forum";
$MESS["F_FILES_COUNT"] = "Maximum number of attachments per message";
$MESS["F_AJAX_POST"] = "Use AJAX in dialogs";
?>